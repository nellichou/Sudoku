import javax.swing.*;
import java.awt.event.*;
import java.io.File;

/**
* La classe ListenerButton est l'observateur des boutons et de la fenêtre de ChoixData.
* @version 1.1
* @author Benjamin Bribant, Nell Telechea
*/

public class ListenerButton implements ActionListener{
    
    /**
    *Variable qui va recevoir la grille de jeu
    */
    private Grille g = new Grille();
    
    /**
    *Variable qui va recevoir le bouton "mode manuel"
    */
    private JButton existant;

    /**
     * Constructeur de la classe ListenerButton.
     * @param existant Le bouton mode manuel
     */
    public ListenerButton(JButton existant) {
        this.existant = existant;
    }

    public void actionPerformed(ActionEvent evenement) {
        if (evenement.getSource() == existant) {

            JFrame fenetre = new JFrame();
            fenetre.setSize(200, 200);
            fenetre.setLocation(100, 100);
            fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            fenetre.setVisible(false);

            JFileChooser select = new JFileChooser(".");
            select.setMultiSelectionEnabled(false);
            int res = select.showDialog(fenetre, "Ouvrir une grille");      //On ouvre une fenêtre qui permet de choisir un fichier.
            if(res == JFileChooser.APPROVE_OPTION) {
            File fifi = select.getSelectedFile();
            String nomFichier = fifi.getAbsolutePath();
            this.g.initGrilleFichier(nomFichier);                           //On initialise la grille avec.
            this.g.afficheGrille();                                         //Puis on l'affiche.

            }
        }
    }
}
