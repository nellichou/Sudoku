import javax.swing.*;
import java.awt.event.*;
import java.io.File;

/**
* La classe ListenerButtonAuto est l'observateur du bouton de la fenêtre de LanceJeuAuto.
* @version 1.1
* @author Benjamin Bribant, Nell Telechea
*/

public class ListenerButtonAuto implements ActionListener {
    
    /**
    *La grille de jeu
    */
    private Grille g = new Grille();

    /**
    *Le temps pris
    */
    private Temps t = new Temps();
    
    /**
    *Variable qui va recevoir le bouton "mode manuel"
    */
    private JButton existant;

    /**
    *Constructeur de la classe ListenerButtonAuto.
    */
    public ListenerButtonAuto(JButton existant) {
        this.existant = existant;
    }

    public void actionPerformed(ActionEvent evenement) {

        if (evenement.getSource() == existant) {

            JFrame fenetre = new JFrame();
            fenetre.setSize(200, 200);
            fenetre.setLocation(100, 100);
            fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            fenetre.setVisible(false);

            JFileChooser select = new JFileChooser(".");
            select.setMultiSelectionEnabled(false);
            int res = select.showDialog(fenetre, "Ouvrir une grille");
            if(res == JFileChooser.APPROVE_OPTION) {
                File fifi = select.getSelectedFile();
                String nomFichier = fifi.getAbsolutePath();
                this.g.initGrilleFichier(nomFichier);
                
                this.t.debut(System.nanoTime());
                if (this.g.solveSudoku( 0, 0)){
                    this.auto=true;
                    this.g.afficheGrille(auto);
                    this.t.fin(System.nanoTime());
                    this.t.affiche();
                }
            }
        }
    }
}
