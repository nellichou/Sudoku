/**
 * La classe Main est le point de départ du programme.
 * @version 1.1
 * @author Benjamin Bribant, Nell Telechea
 */

public class Main {
    /**
     *
     * @param args Arguments de la ligne de commandes
     */
    public static void main(String[] args){
        LancePartie p = new LancePartie();  //On lance la partie.
    }
}